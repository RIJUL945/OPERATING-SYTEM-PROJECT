#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>

#define MAX_COMMAND_LENGTH 1024
#define MAX_ARGS 64
#define MAX_HISTORY 100

typedef struct {
    char command[MAX_COMMAND_LENGTH];
    pid_t pid;
    time_t start_time;
    double duration;
} CommandDetails;

typedef struct {
    CommandDetails commands[MAX_HISTORY];
    int start;
    int end;
    int count;
} History;

History history = { .start = 0, .end = 0, .count = 0 };

void add_to_history(History *history, const char *command, pid_t pid, time_t start_time, double duration) {
    strncpy(history->commands[history->end].command, command, MAX_COMMAND_LENGTH - 1);
    history->commands[history->end].command[MAX_COMMAND_LENGTH - 1] = '\0'; // Ensure null-termination
    history->commands[history->end].pid = pid;
    history->commands[history->end].start_time = start_time;
    history->commands[history->end].duration = duration;
    history->end = (history->end + 1) % MAX_HISTORY;
    if (history->count < MAX_HISTORY) {
        history->count++;
    } else {
        history->start = (history->start + 1) % MAX_HISTORY;
    }
}

void display_exec_details(const History *history) {
    printf("\nExecution Details:\n");
    int index = history->start;
    for (int i = 0; i < history->count; i++) {
        char *start_time_string = ctime(&history->commands[index].start_time);
        start_time_string[strlen(start_time_string) - 1] = '\0'; // Remove newline character
        printf("Command: %s\n", history->commands[index].command);
        printf("PID: %d\n", history->commands[index].pid);
        printf("Start Time: %s\n", start_time_string);
        printf("Duration: %.2f seconds\n\n", history->commands[index].duration);
        index = (index + 1) % MAX_HISTORY;
    }
}

void sigint_handler(int sig) {
    display_exec_details(&history);
    exit(0);
}

void parse_command(char *input, char **args) {
    int i = 0;
    args[i] = strtok(input, " ");
    while (args[i] != NULL) {
        i++;
        args[i] = strtok(NULL, " ");
    }
}

void execute_command(char *command) {
    char *args[MAX_ARGS];
    parse_command(command, args);
    if (execvp(args[0], args) == -1) {
        perror("execvp failed");
        exit(EXIT_FAILURE);
    }
}

void execute_pipeline(char *commands[], int num_commands, int background) {
    int pipefds[2 * (num_commands - 1)];
    pid_t pid;
    int status;

    for (int i = 0; i < num_commands - 1; i++) {
        if (pipe(pipefds + i * 2) == -1) {
            perror("pipe failed");
            exit(1);
        }
    }

    for (int i = 0; i < num_commands; i++) {
        pid = fork();
        if (pid == 0) {
            if (i > 0) {
                if (dup2(pipefds[(i - 1) * 2], 0) == -1) {
                    perror("dup2 failed");
                    exit(1);
                }
            }
            if (i < num_commands - 1) {
                if (dup2(pipefds[i * 2 + 1], 1) == -1) {
                    perror("dup2 failed");
                    exit(1);
                }
            }
            for (int j = 0; j < 2 * (num_commands - 1); j++) {
                close(pipefds[j]);
            }
            execute_command(commands[i]);
        } else if (pid < 0) {
            perror("fork failed");
            exit(1);
        }
    }

    for (int i = 0; i < 2 * (num_commands - 1); i++) {
        close(pipefds[i]);
    }

    if (!background) {
        for (int i = 0; i < num_commands; i++) {
            wait(&status);
        }
    } else {
        printf("Pipeline running in background with PID %d\n", pid);
    }
}
int contains_invalid_characters(const char *input) {
    // Check if the input contains any backslashes or quotes
    for (int i = 0; i < strlen(input); i++) {
        if (input[i] == '\\' || input[i] == '"' || input[i] == '\'') {
            return 1;  
        }
    }
    return 0; 
}
if (contains_invalid_characters(input)) {
    printf("Error: Command contains invalid characters (backslash, single quote, or double quote).\n");
    continue;
}

int main() {
    char input[MAX_COMMAND_LENGTH];
    char *args[MAX_ARGS];
    pid_t pid;
    int status;

    signal(SIGINT, sigint_handler);

    while (1) {
        // Print the prompt
        printf("rijual_ronak@shell ");
        fflush(stdout); // Ensure the prompt is printed immediately

        // Read the command from standard input
        if (fgets(input, sizeof(input), stdin) == NULL) {
            perror("fgets failed");
            continue;
        }

        // Remove the newline character from the input
        input[strcspn(input, "\n")] = 0;

        // Check if the input is empty
        if (strlen(input) == 0) {
            continue;
        }

        // Make a copy of the input command
        char cmd_copy[MAX_COMMAND_LENGTH];
        strncpy(cmd_copy, input, MAX_COMMAND_LENGTH - 1);
        cmd_copy[MAX_COMMAND_LENGTH - 1] = '\0';

        // Check if the command is 'history'
        if (strcmp(input, "history") == 0) {
            display_exec_details(&history);  // Print detailed history instead of just commands
            continue;
        }

        // Check for background process indicator '&'
        int background = 0;
        if (input[strlen(input) - 1] == '&') {
            background = 1;
            input[strlen(input) - 1] = '\0'; // Remove '&' from command
        }

        // Split the command by pipes
        char *commands[MAX_ARGS];
        int num_commands = 0;
        commands[num_commands] = strtok(input, "|");
        while (commands[num_commands] != NULL) {
            num_commands++;
            commands[num_commands] = strtok(NULL, "|");
        }

        if (num_commands > 1) {
            execute_pipeline(commands, num_commands, background);
            add_to_history(&history, cmd_copy, getpid(), time(NULL), 0); // Update PID logic
        } else {
            struct timeval start, end;
            gettimeofday(&start, NULL);
            time_t start_time = time(NULL);

            // Fork and execute the command
            pid = fork();
            if (pid == 0) {
                // Child process
                execute_command(input); // Now input should be parsed correctly
            } else if (pid < 0) {
                // Forking error
                perror("fork failed");
            } else {
                // Parent process
                if (!background) {
                    waitpid(pid, &status, 0);
                    // Record end time, calculate duration, and add to history
                    gettimeofday(&end, NULL);
                    double duration = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1e6;
                    add_to_history(&history, input, pid, start_time, duration);
                } else {
                    printf("Process running in background with PID %d\n", pid);
                    add_to_history(&history, cmd_copy, pid, start_time, 0); // Use the correct PID
                }
            }
        }
    }

    return 0;
}
