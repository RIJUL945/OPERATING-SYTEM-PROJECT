Shell Program with Command History Feature

This project implements a basic shell program in C that can execute system commands and keep track of a history of these commands

Functionality

- System commands along with their arguments can be executed
- A history log is maintained for up to 100 recently executed commands, including their process IDs, start times, and durations
- Signals such as SIGCHLD are handled to manage child processes

Overview

Header Files and Macros

MAX_COMMAND_LENGTH sets the limit for command length to 1024 characters
MAX_ARGS restricts the number of arguments to 64
MAX_HISTORY limits the history size to 100 commands

Data Structure

The CommandDetails structure stores details for each command, like the command string, process ID, start time, and duration
The History structure utilizes a circular buffer to manage command history, keeping track of its start, end, and total count

Key Functions

The add_to_history function logs a command’s details into the history buffer
Other functions handle command execution, input parsing, and signal processing

How to Use

1. Makefile compiles and makes executable files of 3 .c files i.e. "shell" , "helloworld" , "fib".
2. Go to WSL , cd myShell-master , then ./shell . Our shell will be opened.
3. Enter any valid system command to execute it. The program will log the command and its details in the history
4. To exit the shell, Ctrl+C key combination

Sample Commands

ls -l
pwd
echo Hello, World

These commands will be executed, and their information will be stored in the command history






DOCUMENTATION:

RIJUL : os.c , fib.c
RONAK : helloworld.c , readme file , makefile



GITHUB LINK :

https://github.com/RIJUL12/OS-ASSIGNMENT-2.git
