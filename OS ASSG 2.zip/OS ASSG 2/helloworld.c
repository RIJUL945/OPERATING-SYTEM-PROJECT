#include <stdio.h>

int main(){
    printf("Welcome to our shell \n");
    printf("Hello and welcome to our shell \n");
    printf("Hello World\n");
}
